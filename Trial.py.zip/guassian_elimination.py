import numpy as np

def gauss_elim(matrix):
    
    # R2 = R2 - (64/25) *R1
    row_2 = []
    for element_1 in range(len(matrix[1])):
        row_2.append(matrix[1][element_1] - (matrix[1][0]/matrix[0][0]) * matrix[0][element_1])
    print(row_2)

    
    row_3 = []
    for elements in range(len(matrix[2])):
        row_3.append(matrix[2][elements] - (matrix[2][0]/matrix[0][0])*matrix[0][elements])
    print(row_3)

    matrix[1] = row_2
    matrix[2] = row_3

    #print(matrix)
    # R3 = R3 - (21/26)R2
    second_row_3 = []
    for element in range(len(matrix[2])):
        second_row_3.append(matrix[2][element] - (matrix[2][1]/matrix[1][1]) * matrix[1][element])
    print(second_row_3)

    matrix[2] = second_row_3
    print(matrix)

matA = [[25,5,1], [64,8,1], [144,12,1]]
gauss_elim(matA)

matA = [[25,5,1], [64,8,1], [144,12,1]]


##############################################################################################################
def lu_decomposition(matrix):

    mult_1 = matrix[1][0]/matrix[0][0]
    print(mult_1)
    row_2 = []
    for element_1 in range(len(matrix[1])):
        row_2.append(matrix[1][element_1] - (mult_1) * matrix[0][element_1])
    #print(row_2)

    mult_2 = matrix[2][0]/matrix[0][0] 
    print(mult_2)   
    row_3 = []
    for elements in range(len(matrix[2])):
        row_3.append(matrix[2][elements] - (mult_2)*matrix[0][elements])
    #print(row_3)

    matrix[1] = row_2
    matrix[2] = row_3

        #print(matrix)
        # R3 = R3 - (21/26)R2
    mult_3 = matrix[2][1]/matrix[1][1]
    print(mult_3)
    second_row_3 = []
    for element in range(len(matrix[2])):
        second_row_3.append(matrix[2][element] - (mult_3) * matrix[1][element])
    #print(second_row_3)

    matrix[2] = second_row_3
    print(matrix)

    identity_matrix = [[1,0,0], [0,1,0], [0,0,1]]
    identity_matrix[1][0] = 1*mult_1
    identity_matrix[2][0] = 1*mult_2
    identity_matrix[2][1] = 1*mult_3

    print(identity_matrix)
    
    l = np.array(identity_matrix)
    U = np.array(matrix)
    lu = l.dot(U)
    print(lu)


lu_decomposition(matA)

