import numpy 
from numpy import array

def fx():
    for x in range(1,11):
        f_of_x = x * x
        x += 1
        print (f_of_x)

     
fx()

row_matrix = array[()]


